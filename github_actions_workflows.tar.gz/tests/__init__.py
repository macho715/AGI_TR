"""
AGI_TR Test Suite
"""
__version__ = "1.0.0"
