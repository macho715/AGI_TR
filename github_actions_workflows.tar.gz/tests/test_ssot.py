"""Tests for SSOT modules"""
import pytest

def test_placeholder():
    assert True
